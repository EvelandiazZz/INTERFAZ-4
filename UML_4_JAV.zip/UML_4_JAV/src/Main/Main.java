package Main;

import yFrame.Login;


public class Main {
    
    public static void main(String[] args){
        
        Login newlogin = new Login();
        newlogin.setVisible(true);

    }
}
